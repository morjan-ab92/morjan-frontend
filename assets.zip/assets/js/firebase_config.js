// Firebase Configuration for J&A Jewelry
// Replace placeholder values with your actual Firebase project credentials

export const firebaseConfig = {
    apiKey: "AIzaSyBfnWtoDZmP5EJ6nnDwVIQ3WcGZ3gZpmco",
    authDomain: "ja-jewerlly.firebaseapp.com",
    projectId: "ja-jewerlly",
    storageBucket: "ja-jewerlly.firebasestorage.app",
    messagingSenderId: "561650456249",
    appId: "1:561650456249:web:9e845a35e4f577e00bad68",
    measurementId: "G-8NBZ6HF759"
  };

